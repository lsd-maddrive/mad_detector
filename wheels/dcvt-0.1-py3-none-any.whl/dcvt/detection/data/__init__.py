from ...common.data.base import create_dataset

import logging
logger = logging.getLogger(__name__)

_datasets = {
    'wider_face': 'dcvt.detection.data.wider_face.WiderFaceDataset',
    'cvat': 'dcvt.detection.data.cvat.CvatDataset',
}

def get_datasets_from_config(
    config,
    labels
):
    ds_config = config.dataset
    
    assert len(labels) > 0
    
    train_datasets = create_dataset(ds_config, 'train', labels, type_mapping=_datasets)
    val_datasets = create_dataset(ds_config, 'valid', labels, type_mapping=_datasets)
    
    return train_datasets, val_datasets




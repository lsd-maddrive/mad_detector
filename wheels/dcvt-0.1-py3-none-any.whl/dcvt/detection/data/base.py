import numpy as np

from torch.utils.data.dataset import Dataset
import torch

from ..preprocessing import Image2TensorOp
from ...common.data.base import BaseImageDataset, ConcatDatasets, PreprocessedDataset, AugmentedDataset


class Image2TensorDataset(Dataset):
    def __init__(self, dataset, max_targets=60, scale_div=255):
        self.op = Image2TensorOp(scale_div=scale_div)
        self.dataset = dataset
        self.max_targets = max_targets
        self.scale_div = scale_div

    def __getitem__(self, index):
        img, ann = self.dataset[index]

        bboxes = np.array(ann['bboxes'])
        labels = np.array(ann['labels'])

        # Set from config
        shaped_bboxes = np.zeros([self.max_targets, 5])

        if len(labels) > 0:
            bboxes_labels = np.hstack((bboxes, labels[..., np.newaxis]))
            bboxes_count = min(bboxes_labels.shape[0], self.max_targets)
            shaped_bboxes[:bboxes_count] = bboxes_labels[:bboxes_count]

        img, ann = self.op.transform(img, {'bboxes': shaped_bboxes})
        return img, ann['bboxes']

    def __len__(self):
        return len(self.dataset)


# TODO - try to use it (before add to config parameters)!
class MosaicAugmentedDataset(BaseImageDataset):
    def __init__(self, dataset, net_input_sz_hw, offset=0.3, prob=0.3, valid_bbox_ratio=0.5):
        self.prob = prob
        self.offset = offset
        self.dataset = dataset
        self.valid_bbox_ratio = valid_bbox_ratio
        self.net_input_sz_hw = net_input_sz_hw
    
    def __len__(self):
        return len(self.dataset)
    
    def get_image_annotation(self, index):
        offset = self.offset
        im_h, im_w = self.net_input_sz_hw

        xc = int(random.uniform(im_w*offset, im_w*(1-offset)))
        yc = int(random.uniform(im_h*offset, im_h*(1-offset)))
        zones = np.array([
            [0, 0, xc, yc],         # top left
            [xc, 0, im_w, yc],      # top right
            [0, yc, xc, im_h],      # bottom left
            [xc, yc, im_w, im_h]    # bottom right
        ])

        img4 = np.zeros((*self.net_input_sz_hw, 3), dtype=np.uint8)

        indices = [index] + \
            [random.randint(0, len(self.dataset) - 1) for _ in range(3)]
        bboxes_lbls4 = []

        for i, index in enumerate(np.random.permutation(indices)):
            img, ann = self.dataset[index]            
            bboxes, labels = ann['bboxes'], ann['labels']

            is_empty_ann = bboxes.shape[0] == 0
            zone_xyxy = zones[i]

            img4[zone_xyxy[1]:zone_xyxy[3], zone_xyxy[0]:zone_xyxy[2]] = \
                img[zone_xyxy[1]:zone_xyxy[3], zone_xyxy[0]:zone_xyxy[2]]

            if not is_empty_ann:
                bboxes_lbls = np.hstack([
                    bboxes, labels[:, None]
                ])

                tl_points = bboxes[:, :2]
                br_points = bboxes[:, :2] + bboxes[:, 2:4]
                areas = bboxes[:, 2]*bboxes[:, 3]

                tl = np.maximum(zone_xyxy[:2], tl_points)
                br = np.minimum(zone_xyxy[2:], br_points)

                en = (tl < br).prod(axis=1)
                area_i = np.prod(br - tl, axis=1) * en

                valid_boxes = area_i/areas > self.valid_bbox_ratio

                if sum(valid_boxes) > 0:
                    bboxes_lbls4.append(bboxes_lbls[valid_boxes])


        if len(bboxes_lbls4) > 0:
            bboxes_lbls4 = np.concatenate(bboxes_lbls4)

            bboxes = bboxes_lbls4[:, :4] 
            labels = bboxes_lbls4[:, 4]
        else:
            bboxes, labels = np.array([]), np.array([])
        
        return img4, {
            'bboxes': bboxes,
            'labels': labels
        }

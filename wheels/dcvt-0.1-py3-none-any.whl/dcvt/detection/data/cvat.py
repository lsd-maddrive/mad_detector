import os
import cv2
import numpy as np
import xml.etree.ElementTree as ET

from . base import BaseImageDataset

import logging


class CvatDataset(BaseImageDataset):
    def __init__(
        self,
        root_dirpath,
        img_sdirpath=None,
        ann_sfpath=None,
        **other
    ):
        super().__init__(**other)

        self.logger = logging.getLogger(__name__)

        self.labels = other['labels']

        self.root_dpath = root_dirpath
        if img_sdirpath is None:
            self.imgs_dpath = self.root_dpath
        else:
            self.imgs_dpath = os.path.join(self.root_dpath, img_sdirpath)

        if ann_sfpath is None:
            ann_sfpath = 'instances_default.json'
        self.ann_fpath = os.path.join(self.root_dpath, ann_sfpath)

        self.annots = self._parse_annotation(self.ann_fpath, self.labels)
        
        if other.get('show_stats', False):
            self.logger.info(f'Dataset {__class__} readed {len(self)} annotations')

    def __len__(self):
        return len(self.annots)

    def __getitem__(self, index):
        img = self.get_image(index)
        ann = self.get_annotation(index)

        return img, ann

    def get_annotation(self, index):
        annot = self.annots[index]

        bboxes = []
        labels = []

        for ann in annot['objects']:
            ann_label = ann['label']

            # COCO format
            bbox = [
                ann['xmin'], ann['ymin'],
                ann['width'],
                ann['height']
            ]

            bboxes.append(bbox)
            label_id = self.labels.index(ann_label)
            labels.append(label_id)

        bboxes = np.array(bboxes, dtype=np.float)
        labels = np.array(labels, dtype=np.float)

        if np.any(bboxes < 0):
            print(bboxes, annot)

        assert np.all(bboxes >= 0)

        return {
            'bboxes': bboxes,
            'labels': labels,
            'width': annot['width'],
            'height': annot['height']
        }

    def get_image(self, index):
        annot = self.annots[index]

        filename = annot['filename']
        # Extract only basename
        if os.sep in filename:
            filename = os.path.basename(filename)

        img_fpath = os.path.join(self.imgs_dpath, filename)
        img = cv2.imread(img_fpath)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        return img

    def _parse_annotation(self, ann_fpath, labels=[]):
        all_insts = []
        try:
            tree = ET.parse(ann_fpath)
        except Exception as e:
            raise Exception(f'Failed to parse annotation: {ann_fpath} [{e}]')

        for img_item in tree.findall('image'):
            img = {
                'objects': [],
                'filename': img_item.attrib['name'],
                'width': int(img_item.attrib['width']),
                'height': int(img_item.attrib['height']),
            }

            for box in img_item.findall('box'):
                obj_label = box.attrib['label']
                if labels and obj_label not in labels:
                    print(f'Ignore label: {obj_label}')
                    continue

                obj = {
                    'label': obj_label,
                    'xmin': float(box.attrib['xtl']),
                    'ymin': float(box.attrib['ytl']),
                    'xmax': float(box.attrib['xbr']),
                    'ymax': float(box.attrib['ybr']),
                }

                obj['xmin'] = np.clip(obj['xmin'], 0, img['width'])
                obj['xmax'] = np.clip(obj['xmax'], 0, img['width'])
                obj['ymin'] = np.clip(obj['ymin'], 0, img['height'])
                obj['ymax'] = np.clip(obj['ymax'], 0, img['height'])

                obj['width'] = obj['xmax'] - obj['xmin']
                obj['height'] = obj['ymax'] - obj['ymin']

                fname = img['filename']
                assert obj['width'] > 0, f'Image {fname} has invalid width'
                assert obj['height'] > 0, f'Image {fname} has invalid height'

                img['objects'].append(obj)

            all_insts.append(img)

        return all_insts

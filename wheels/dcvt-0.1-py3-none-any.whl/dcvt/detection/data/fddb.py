import os
import cv2
import math
import numpy as np

from . base import BaseImageDataset
from ...common.utils.fs import get_images_from_directory

import logging


class FDDBFaceDataset(BaseImageDataset):
    """Dataset parser for http://vis-www.cs.umass.edu/fddb/


    """
    def __init__(self,
                 root_dirpath,
                 img_sdirpath,
                 ann_sfpath,
                 n_images=-1,
                 **other):

        self.logger = logging.getLogger(__name__)

        self.n_images = n_images
        self.root_dpath = root_dirpath
        self.imgs_dpath = os.path.join(self.root_dpath, img_sdirpath)

        # Set from code
        self.labels = other['labels']

        raise NotImplementedError('TODO')

        # Path to txt file
        self.ann_fpath = os.path.join(self.root_dpath, ann_sfpath)

        # Recursive search of images
        self.images_fpaths = get_images_from_directory(self.imgs_dpath, is_recursive=True)

        self.images_map = {
            os.path.basename(fpath): fpath
            for fpath in self.images_fpaths
        }

        # This dataset contains only faces
        self.ds_label_name = 'face'

        if self.ds_label_name not in self.labels:
            raise Exception(f'Dataset label {self.ds_label_name} not found in requested labels: {self.labels}')

        self.anns_map = self._parse_annotation(self.ann_fpath)
        self.anns_files = list(self.anns_map.keys())

        # Debug feature for fast processing
        if self.n_images > 0:
            self.anns_files = self.anns_files[:self.n_images]

        if other.get('show_stats', False):
            self.logger.info(f'Dataset {__class__} readed {len(self)} annotations')

    def __len__(self):
        return len(self.anns_files)

    def __getitem__(self, index):
        im_fname = self.anns_files[index]
        im_fpath = self.images_map[im_fname]

        img = cv2.imread(im_fpath)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        height, width = img.shape[:2]

        ann = self.get_annotation(index)
        ann['width'] = width
        ann['height'] = height

        return img, ann

    def get_annotation(self, index):
        im_fname = self.anns_files[index]
        ann = self.anns_map[im_fname]
        label_id = self.labels.index('face')
        labels = [label_id for _ in ann['bboxes']]
        
        return {
            'bboxes': ann['bboxes'],
            'labels': labels,
        }

    def _parse_annotation(self, path):
        anns = {}
        with open(path) as f:
            while True:
                imFilename = f.readline().strip()
                if not imFilename:
                    break
                
                # Invalid filename
                im_filepath = os.path.join(self.imgs_dpath, imFilename)
                if not os.path.exists(im_filepath):
                    self.logger.warning(f'Failed to find image: {im_filepath}')
                    continue

                im_basename = os.path.basename(imFilename)
                nbBndboxes = f.readline()

                bboxes = []
                i = 0
                for i in range(int(nbBndboxes)):
                    i = i + 1
                    maj_ax_r, min_ax_r, angle, xc, yc, _ = [float(i) for i in f.readline().split()]

                    calc_x = math.sqrt(maj_ax_r**2 * math.cos(angle)**2 + min_ax_r**2 * math.sin(angle)**2)
                    calc_y = math.sqrt(maj_ax_r**2 * math.sin(angle)**2 + min_ax_r**2 * math.cos(angle)**2)

                    bbox_x = xc / img_width
                    bbox_y = yc / img_height
                    bbox_w = (2 * calc_x) / img_width
                    bbox_h = (2 * calc_y) / img_height

                    bbox = [
                        xc-calc_x,
                        yc-calc_y, 
                        2 * calc_x,
                        2 * calc_y
                    ]

                    if np.sum(bbox) == 0:
                        continue

                    bboxes.append(bbox)

                anns[im_basename] = {
                    'bboxes': bboxes
                }
        
        return anns



import torch
from torch.nn import BatchNorm2d
import numpy as np
import json
import os
from pathlib import Path
import logging

from ..utils.bbox import TorchIoUBBox, diou_xywh_torch
from ..utils.nms import TorchNMS
from ..models import construct_model
from ...common.utils.torch import set_half_precision

from ..preprocessing import deserialize_preprocessing
from concurrent.futures import ProcessPoolExecutor as PoolExecutor


class InferDetection():
    def __init__(
        self, model, device=None, nms_threshold=0.6, conf_threshold=0.4, 
        use_soft_nms=False, use_half_precision=False, n_processes=1
    ):
        self.model = model
        self.config = model.config
        
        self.logger = logging.getLogger(__name__)
        self.logger.debug(f'Loading model with config: {self.config}')

        self.n_processes = n_processes
        self.model_hw = self.config['infer_sz_hw']
        self.use_half_precision = use_half_precision
        self.use_soft_nms = use_soft_nms

        self.device = device
        if self.device is None:
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        
        if isinstance(self.device, str):
            self.device = torch.device(self.device)

        self.model.to(self.device)
        self.model.eval()

        if self.use_half_precision:
            set_half_precision(self.model)

        self.nms_threshold = nms_threshold
        self.conf_threshold = conf_threshold
        self.labels = self.config['labels']

        self._size_tnsr = torch.FloatTensor([
            self.model_hw[1],
            self.model_hw[0],
            self.model_hw[1],
            self.model_hw[0],
        ]).view(1, 1, 4).to(self.device)

        # self.image_2_tensor_op = deserialize_preprocessing([self.config['image_2_tensor']])[0]
        self.preproc_ops = deserialize_preprocessing(self.config['preprocessing'])
        # We can append as operations has same order
        # self.preproc_ops.append(self.image_2_tensor_op)
        
        self.nms = TorchNMS(
            iou=diou_xywh_torch,
            iou_threshold=nms_threshold
        )

    def map_labels(self, label_ids):
        return [self.labels[id_] for id_ in label_ids]

    @property
    def name(self):
        return self.model.__name__
        
    @classmethod
    def from_config(cls, model_config: dict, **kwargs):
        """Create model from config, it creates another instance so to sync use update_model_state()

        Args:
            model_config (dict): model configuration

        Returns:
            InferDetection: class for inference
        """
        model = construct_model(model_config, inference=True)
        return cls(model=model, **kwargs)

    @classmethod
    def from_file(cls, model_filepath: str, **kwargs):
        """Create model from serialized file, it creates another instance so to sync use update_model_state()

        Args:
            model_filepath (str): model path to file in filesystem

        Returns:
            InferDetection: class for inference
        """
        loaded_data = torch.load(model_filepath)
        model_config = loaded_data['model_config']
        model_state = loaded_data['model_state']
        
        model = cls.from_config(
            model_config=model_config,
            **kwargs
        )
        model.update_model_state(model_state)
        return model

    def get_labels(self):
        return self.labels

    def update_model_state(self, model_state):
        self.model.load_state_dict(model_state)

    def infer_image(self, image):
        return self.infer_batch([image])[0]

    def infer_batch(self, imgs_list):
        batch_tensor = []
        
        # Letterboxing can be optimized with applying matrix operations (scale, pad)
        preproc_data = []
        for img in imgs_list:
            data = {}
            for op in self.preproc_ops:
                img, _ = op.transform(img, data=data)

            preproc_data.append(data)
            batch_tensor.append(img)

        batch_tensor = torch.stack(batch_tensor, axis=0)
        
        # NOTE - here we don`t apply shift and scale to all bboxes at once - just to demonstrate
        with torch.no_grad():
            batch_tensor = batch_tensor.to(self.device)
            if self.use_half_precision:
                batch_tensor = batch_tensor.half()

            outputs = self.model(batch_tensor)
            outputs[..., :4] *= self._size_tnsr
            
            if self.use_half_precision:
                outputs = outputs.float()

            outputs = outputs.cpu()

        # Go through batches
        result_list = []

        if self.n_processes > 1:
            with PoolExecutor(self.n_processes) as ex:
                futures = []
                for i, output in enumerate(outputs):
                    # Normalized
                    preds = output[output[..., 4] > self.conf_threshold]
                    fut = ex.submit(
                        self.process_prediction, 
                        preds, preproc_data[i], self.nms, self.preproc_ops
                    )
                    futures.append(fut)

                for fut in futures:
                    bboxes, labels, scores = fut.result()
                    # Tuple of three components
                    result_list.append((
                        bboxes,
                        labels,
                        scores,
                    ))
        else:
            for i, output in enumerate(outputs):
                preds = output[output[..., 4] > self.conf_threshold]
                # print(f'Received {preds.shape} predictions')

                bboxes, labels, scores = self.process_prediction(
                    preds, preproc_data[i], self.nms, self.preproc_ops
                )
                result_list.append((
                    bboxes,
                    labels,
                    scores,
                ))

        return result_list

    @staticmethod
    def process_prediction(preds, preproc_data, nms, preproc_ops):
        if preds.shape[0] == 0:
            return np.array([]), np.array([]), np.array([])

        keep = nms.exec(preds)
        
        preds = preds[keep] #.cpu()
        for op in reversed(preproc_ops):
            preds = op.inverse_transform(preds=preds, data=preproc_data)

        bboxes = preds[:, :4]
        labels = preds[:, 5].astype(int)
        scores = preds[:, 4]

        return bboxes, labels, scores

import cv2
import numpy as np
import torch
from ...common.utils import image as imut
from ...common.preprocessing.base import serialize_preprocessing, BasePreprocessingOp
import logging

logger = logging.getLogger(__name__)


def deserialize_preprocessing(descriptions):
    logger.debug("Deserializing descriptions")
    logger.debug(descriptions)
    ops = []
    for desc in descriptions:
        ops.append(BasePreprocessingOp.deserialize(desc, _OPERATIONS))
    return ops


class Image2TensorOp(BasePreprocessingOp):
    TYPE = "image2tensor"

    def __init__(self, scale_div):
        self.scale_div = scale_div

    def transform(self, img, ann=None, data={}):
        img = torch.from_numpy(img).float().div(self.scale_div).permute(2, 0, 1)

        if ann is not None:
            if "bboxes" in ann:
                ann["bboxes"] = torch.from_numpy(ann["bboxes"])

        return img, ann

    def inverse_transform(self, preds: torch.Tensor, data: dict):
        return preds.numpy()

    @staticmethod
    def from_description(scale_div, **other):
        return Image2TensorOp(scale_div)

    def serialize(self):
        return {"scale_div": self.scale_div}


class BboxValidationOp(BasePreprocessingOp):
    TYPE = "bbox_validation"

    def __init__(self):
        pass

    def _validate_bboxes(self, bboxes, im_shape):
        bboxes[:, 2:4] = bboxes[:, :2] + bboxes[:, 2:4]

        # X, Y side
        bboxes[:, [0, 2]] = np.clip(bboxes[:, [0, 2]], 0, im_shape[1])
        bboxes[:, [1, 3]] = np.clip(bboxes[:, [1, 3]], 0, im_shape[0])
        bboxes[:, 2:4] = bboxes[:, 2:4] - bboxes[:, :2]

        return bboxes

    def transform(self, img, ann=None, data={}):
        if ann is not None:
            bboxes = ann["bboxes"]
            labels = ann["labels"]
            if len(bboxes) > 0:
                # Remove bboxes that are 0 width/height
                mask = np.prod(bboxes[:, 2:4], axis=1) > 0
                ann["bboxes"] = bboxes = bboxes[mask]
                ann["labels"] = np.array(labels)[mask]

                if len(bboxes) > 0:
                    ann["bboxes"] = self._validate_bboxes(bboxes, img.shape[:2])

        return img, ann

    def inverse_transform(self, preds: np.ndarray, data: dict):
        return preds

    @staticmethod
    def from_description(**other):
        return BboxValidationOp()

    def serialize(self):
        return {}


class LetterboxingOp(BasePreprocessingOp):
    TYPE = "letterboxing"

    def __init__(self, target_sz, fill_value=127):
        """Letterboxing operation

        Args:
            target_sz (tuple): Target size (HW - height x width format)
            fill_value (int, optional): Value to fill image after resize. Defaults to 127.
        """
        self.images_interp = cv2.INTER_AREA
        self.img_fill_value = fill_value

        self.target_sz = np.array(target_sz, dtype=int)

    def transform(self, img, ann=None, data={}):
        img, params = imut.letterbox(
            img,
            inter=self.images_interp,
            target_sz=self.target_sz,
            background=self.img_fill_value,
        )

        if ann is not None:
            ann["height"], ann["width"] = img.shape[:2]
            if "bboxes" in ann:
                bboxes = np.array(ann["bboxes"], dtype=np.float32)
                ann["bboxes"] = imut.letterbox_bboxes(bboxes, params)

        data["letterboxing"] = params
        return img, ann

    def inverse_transform(self, preds: np.ndarray, data: dict):
        params = data["letterboxing"]
        preds = imut.inverse_letterbox_bboxes(preds, params)
        return preds

    @staticmethod
    def from_description(target_sz, fill_value, **other):
        return LetterboxingOp(target_sz=target_sz, fill_value=fill_value)

    def serialize(self):
        return {
            "target_sz": self.target_sz.tolist(),
            "fill_value": self.img_fill_value,
        }


_OPERATIONS = [LetterboxingOp, BboxValidationOp, Image2TensorOp]

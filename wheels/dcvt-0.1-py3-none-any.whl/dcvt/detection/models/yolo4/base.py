from . losses import YoloBboxLoss
from ....common.models.base import ImageProcessingModel


class BaseYolo4(ImageProcessingModel):
    def __init__(self, **config):
        super().__init__(**config)

        self.loss_obj = YoloBboxLoss(config)

    def loss(self, y_pred, y_true):
        return self.loss_obj(y_pred, y_true)

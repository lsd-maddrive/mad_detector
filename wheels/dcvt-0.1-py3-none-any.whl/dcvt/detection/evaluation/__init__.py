import numpy as np

from ..utils.bbox import iou_xywh_numpy


class MetricsEvaluator(object):
    AP_METRIC_NAME = 'ap'
    MAP_METRIC_NAME = 'map'

    def __init__(
        self, labels, thresholds=[.5, .75],
        required=[AP_METRIC_NAME, MAP_METRIC_NAME]
    ):
        self.required = required
        self.labels = labels
        self.thresholds = thresholds

        self.clear()

    def _process_sample(self, pred, true, threshold, label_id):
        FP = []
        TP = []
        scores = []
        gt_count = 0
        
        pr_bboxes, pr_labels, pf_confs = pred
        gt_bboxes, gt_labels = true

        gt_labels = np.array(gt_labels)
        gt_bboxes = np.array(gt_bboxes)

        # Filter GT data for certain label
        gt_lbl_mask = gt_labels == label_id
        gt_bboxes = gt_bboxes[gt_lbl_mask]
    
        gt_count += gt_bboxes.shape[0]

        if len(pr_bboxes) == 0:
            return TP, FP, scores, gt_count

        # Sort by confidence
        det_sort_indices = np.argsort(-pf_confs)
        pr_bboxes = pr_bboxes[det_sort_indices]
        pf_confs = pf_confs[det_sort_indices]
        pr_labels = pr_labels[det_sort_indices]
        
        # Get data for current label
        pred_lbl_mask = pr_labels == label_id        
        pr_bboxes = pr_bboxes[pred_lbl_mask]
        pr_confs = pf_confs[pred_lbl_mask]

        # Minus for reversed sort
        scores.extend(-pr_confs)
        
        if gt_bboxes.shape[0] == 0:
            for i_pred in range(pr_confs.shape[0]):
                TP.append(0)
                FP.append(1)
            return TP, FP, scores, gt_count
        
        iou_mtrx = iou_xywh_numpy(pr_bboxes, gt_bboxes)
        
        used_gt = []
        
        for i_pred in range(iou_mtrx.shape[0]):
            i_gt = np.argmax(iou_mtrx[i_pred])
            
            if i_gt not in used_gt and iou_mtrx[i_pred, i_gt] > threshold:               
                TP.append(1)
                FP.append(0)
                used_gt.append(i_gt)
            else:
                TP.append(0)
                FP.append(1)
        
        return TP, FP, scores, gt_count
        

    def append_sample(self, pred, true):
        gt_bboxes = true['bboxes']
        gt_labels = true['labels']

        for threshold in self.thresholds:
            for check_label_id, label in enumerate(self.labels):
                r_TP, r_FP, r_scores, r_gt_count = self._process_sample(
                    pred, (gt_bboxes, gt_labels), threshold, check_label_id
                )

                self.metrics[threshold][label]['TP'].extend(r_TP)
                self.metrics[threshold][label]['FP'].extend(r_FP)
                self.metrics[threshold][label]['scores'].extend(r_scores)
                self.metrics[threshold][label]['gt_count'] += r_gt_count   

    def clear(self):
        self.metrics = {
            t: {
                l: {
                    'TP': [],
                    'FP': [],
                    'scores': [],
                    'gt_count': 0
                } for l in self.labels
            } for t in self.thresholds
        }

    def get_metrics(self):
        result = {}

        for threshold in self.thresholds:
            ap_values = []
            for check_label_id, label in enumerate(self.labels):
                TP = np.array(self.metrics[threshold][label]['TP'])
                FP = np.array(self.metrics[threshold][label]['FP'])
                scores = np.array(self.metrics[threshold][label]['scores'])
                gt_count = np.array(self.metrics[threshold][label]['gt_count'])

                indices = np.argsort(scores)
                acc_TP = np.cumsum(TP[indices])
                acc_FP = np.cumsum(FP[indices])

                rec = acc_TP / gt_count
                prec = np.divide(acc_TP, (acc_FP + acc_TP))

                ap, _, _, _ = calculate_ap_interpolated(rec, prec)
                ap_values.append(ap)

                if self.AP_METRIC_NAME in self.required:
                    rounded_thresh = int(threshold*100)
                    name = f'{self.AP_METRIC_NAME}{rounded_thresh}_{label}'
                    result[name] = ap
        
            if self.MAP_METRIC_NAME in self.required:
                name = f'{self.MAP_METRIC_NAME}{rounded_thresh}'
                result[name] = np.mean(ap_values)

        return result


def calculate_ap_interpolated(rec, prec, generate_plot=False):
    mrec = rec
    mpre = prec
    
    recallValues = np.linspace(0, 1, 11)
    recallValues = list(recallValues[::-1])
    rhoInterp = []
    recallValid = []
    # For each recallValues (0, 0.1, 0.2, ... , 1)
    for r in recallValues:
        # Obtain all recall values higher or equal than r
        recall_gr_inds = np.argwhere(mrec >= r)
        pmax = 0
        # If there are recalls above r
        if recall_gr_inds.size != 0:
            pmax = max(mpre[recall_gr_inds.min():])
        recallValid.append(r)
        rhoInterp.append(pmax)
    # By definition AP = sum(max(precision whose recall is above r))/11
    ap = sum(rhoInterp) / 11
    # Generating values for the plot
    if generate_plot:
        rvals = [recallValid[0]]
        [rvals.append(e) for e in recallValid]
        rvals.append(0)
        pvals = [0]
        [pvals.append(e) for e in rhoInterp]
        pvals.append(0)
        # rhoInterp = rhoInterp[::-1]
        cc = []
        for i in range(len(rvals)):
            p = (rvals[i], pvals[i - 1])
            if p not in cc:
                cc.append(p)
            p = (rvals[i], pvals[i])
            if p not in cc:
                cc.append(p)
        recallValues = [i[0] for i in cc]
        rhoInterp = [i[1] for i in cc]
    
    return [ap, rhoInterp, recallValues, None]


# Thanks to https://github.com/rafaelpadilla/Object-Detection-Metrics
def calculate_ap(rec, prec):
    mrec = [0]
    [mrec.append(e) for e in rec]
    mrec.append(1)
    
    mpre = [0]
    [mpre.append(e) for e in prec]
    mpre.append(0)
    
    for i in range(len(mpre) - 1, 0, -1):
        mpre[i - 1] = max(mpre[i - 1], mpre[i])
    ii = []
    for i in range(len(mrec) - 1):
        if mrec[1:][i] != mrec[0:-1][i]:
            ii.append(i + 1)
    ap = 0
    for i in ii:
        ap = ap + np.sum((mrec[i] - mrec[i - 1]) * mpre[i])
    # return [ap, mpre[1:len(mpre)-1], mrec[1:len(mpre)-1], ii]
    return [ap, mpre[0:len(mpre) - 1], mrec[0:len(mpre) - 1], ii]


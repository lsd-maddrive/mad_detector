import numpy as np
import torch

# Check https://github.com/facebookresearch/detr/blob/master/util/box_ops.py
# https://pytorch.org/docs/stable/_modules/torchvision/ops/boxes.html#box_iou

def iou_xywh_numpy(bboxes_a, bboxes_b):
    assert bboxes_a.shape[1] == 4, 'bboxes must have shape [:, 4]'
    assert bboxes_b.shape[1] == 4, 'bboxes must have shape [:, 4]'

    a_br = bboxes_a[:, None, :2] + bboxes_a[:, None, 2:]
    b_br = bboxes_b[:, :2] + bboxes_b[:, 2:]

    # intersection top left
    tl = np.maximum(bboxes_a[:, None, :2], bboxes_b[:, :2])
    # intersection bottom right
    br = np.minimum(a_br, b_br)

    area_a = np.prod(bboxes_a[:, 2:], axis=1)
    area_b = np.prod(bboxes_b[:, 2:], axis=1)

    en = (tl < br).astype(tl.dtype).prod(axis=2)
    area_i = np.prod(br - tl, 2) * en  # * ((tl < br).all())
    area_u = area_a[:, None] + area_b - area_i
    iou = area_i / area_u

    return iou


def iou_wh_numpy(bboxes_a, bboxes_b):
    assert bboxes_a.shape[1] == 2, 'bboxes must have shape [:, 2]'
    assert bboxes_b.shape[1] == 2, 'bboxes must have shape [:, 2]'

    # intersection
    br = np.minimum(bboxes_a[:, None], bboxes_b)

    area_a = np.prod(bboxes_a, axis=1)
    area_b = np.prod(bboxes_b, axis=1)

    area_i = np.prod(br, 2)
    area_u = area_a[:, None] + area_b - area_i
    iou = area_i / area_u

    return iou


def diou_xywh_torch(bboxes_a, bboxes_b):
    assert bboxes_a.shape[1] == 4
    assert bboxes_b.shape[1] == 4
    
    a_tl = bboxes_a[:, None, :2]
    b_tl = bboxes_b[:, :2]

    a_sz = bboxes_a[:, 2:]
    b_sz = bboxes_b[:, 2:]
    
    a_br = a_tl + bboxes_a[:, None, 2:]
    b_br = b_tl + b_sz

    # intersection top left
    tl = torch.max(a_tl, b_tl)
    # intersection bottom right
    br = torch.min(a_br, b_br)
    # convex (smallest enclosing box) top left and bottom right
    con_tl = torch.min(a_tl, b_tl)
    con_br = torch.max(a_br, b_br)

    area_a = torch.prod(a_sz, 1)
    area_b = torch.prod(b_sz, 1)

    en = (tl < br).type(tl.type()).prod(dim=2)
    area_i = torch.prod(br - tl, 2) * en  # * ((tl < br).all())
    area_u = area_a[:, None] + area_b - area_i
    iou = area_i / area_u

    # centerpoint distance squared
    a_cntr = (a_tl + a_br)/2
    b_cntr = (b_tl + b_br)/2
    rho2 = ((a_cntr - b_cntr) ** 2).sum(dim=-1)

    c2 = torch.pow(con_br - con_tl, 2).sum(dim=2) + 1e-16
    return iou - rho2 / c2


class TorchIoUBBox(object):
    def __init__(self, method='vanila', format_='xywh'):
        self.method = method.lower()

        heads = {
            'xywh': self._xywh_head,
            'xyxy': self._xyxy_head,
            'xcycwh': self._xcycwh_head
        }

        self._head = heads[format_]

    def __call__(self, bboxes_a, bboxes_b):
        return self.bboxes_iou(
            bboxes_a, 
            bboxes_b,
        )

    def _xyxy_head(self, bboxes_a, bboxes_b):
        a_tl = bboxes_a[:, None, :2]
        b_tl = bboxes_b[:, :2]
        
        a_br = bboxes_a[:, None, 2:]
        b_br = bboxes_b[:, 2:]

        a_sz = bboxes_a[:, 2:] - bboxes_a[:, :2]
        b_sz = b_br - b_tl
        
        return (a_tl, b_tl, a_br, b_br, a_sz, b_sz)
    
    def _xywh_head(self, bboxes_a, bboxes_b):
        a_tl = bboxes_a[:, None, :2]
        b_tl = bboxes_b[:, :2]

        a_sz = bboxes_a[:, 2:]
        b_sz = bboxes_b[:, 2:]
        
        a_br = a_tl + bboxes_a[:, None, 2:]
        b_br = b_tl + b_sz
        
        return (a_tl, b_tl, a_br, b_br, a_sz, b_sz)
    
    def _xcycwh_head(self, bboxes_a, bboxes_b):
        a_tl = bboxes_a[:, None, :2] - bboxes_a[:, None, 2:]/2
        b_tl = bboxes_b[:, :2] - bboxes_b[:, 2:]

        a_sz = bboxes_a[:, 2:]
        b_sz = bboxes_b[:, 2:]
        
        a_br = a_tl + bboxes_a[:, None, 2:]
        b_br = b_tl + b_sz
        
        return (a_tl, b_tl, a_br, b_br, a_sz, b_sz)
        
    def bboxes_iou(self, bboxes_a, bboxes_b, GIoU=False, DIoU=False, CIoU=False):
        assert bboxes_a.shape[1] == 4
        assert bboxes_b.shape[1] == 4
        
        a_tl, b_tl, a_br, b_br, a_sz, b_sz = self._head(bboxes_a, bboxes_b)
        
        # intersection top left
        tl = torch.max(a_tl, b_tl)
        # intersection bottom right
        br = torch.min(a_br, b_br)
        # convex (smallest enclosing box) top left and bottom right
        con_tl = torch.min(a_tl, b_tl)
        con_br = torch.max(a_br, b_br)

        area_a = torch.prod(a_sz, 1)
        area_b = torch.prod(b_sz, 1)

        en = (tl < br).type(tl.type()).prod(dim=2)
        area_i = torch.prod(br - tl, 2) * en  # * ((tl < br).all())
        area_u = area_a[:, None] + area_b - area_i
        iou = area_i / area_u

        def giou_tail():
            area_c = torch.prod(con_br - con_tl, 2)
            return iou - (area_c - area_u) / area_c

        def diou_tail():
            # centerpoint distance squared
            a_cntr = (a_tl + a_br)/2
            b_cntr = (b_tl + b_br)/2
            rho2 = ((a_cntr - b_cntr) ** 2).sum(dim=-1)
        
            c2 = torch.pow(con_br - con_tl, 2).sum(dim=2) + 1e-16
            return iou - rho2 / c2

        def ciou_tail():
            w1 = a_sz[:, 0]
            h1 = a_sz[:, 1]
            w2 = b_sz[:, 0]
            h2 = b_sz[:, 1]
            
            # centerpoint distance squared
            a_cntr = (a_tl + a_br)/2
            b_cntr = (b_tl + b_br)/2
            rho2 = ((a_cntr - b_cntr) ** 2).sum(dim=-1)
            
            c2 = torch.pow(con_br - con_tl, 2).sum(dim=2) + 1e-16
            v = (4 / math.pi ** 2) * torch.pow(torch.atan(w1 /
                                                        h1).unsqueeze(1) - torch.atan(w2 / h2), 2)
            with torch.no_grad():
                alpha = v / (1 - iou + v)
            return iou - (rho2 / c2 + v * alpha)
        
        def vanila_tail():
            return iou
        
        tails = {
            'vanilla': vanila_tail,
            'giou': giou_tail,
            'diou': diou_tail,
            'ciou': ciou_tail,
        }
        
        return tails[self.method]()

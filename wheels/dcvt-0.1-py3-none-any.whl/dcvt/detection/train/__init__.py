import os
import time
import logging
import os
import math
import argparse
from collections import deque
import datetime
import cv2
import json
import numpy as np
from tqdm import tqdm

from torch.utils.data import DataLoader
import torch

from ...common.utils import remote
from ...common.utils.common import (
    set_determenistic,
    object_from_dict,
    flatten_dict,
    unflatten_dict,
    merge_update_dicts,
    MetricTracker,
)
from ...common.utils.torch import initialize_weights, get_lr
from ...common.utils.config import read_config, write_temp_yml
from ...common.evaluation import BatchEvaluator
from ...common.utils.tracking import ExperimentTrackingLogger
from ...common.utils.fs import FilepathLoader
from ...common.train import SubbatchTrainer

from ..models import construct_model
from ..infer import InferDetection
from ..preprocessing import (
    LetterboxingOp,
    BboxValidationOp,
    serialize_preprocessing,
    deserialize_preprocessing,
)
from ..evaluation import MetricsEvaluator
from ..data.base import (
    ConcatDatasets,
    PreprocessedDataset,
    AugmentedDataset,
    Image2TensorDataset,
)
from ..data import get_datasets_from_config
import logging

logger = logging.getLogger(__name__)


def load_datasets(config):
    result = {}

    train_datasets, val_datasets = get_datasets_from_config(config, config.model.labels)

    raw_train_dataset = ConcatDatasets(datasets=train_datasets)
    raw_val_dataset = ConcatDatasets(datasets=val_datasets)
    result["raw"] = (raw_train_dataset, raw_val_dataset)

    # Set list of base preprocessing
    preproc_ops = [
        LetterboxingOp(target_sz=config.model.infer_sz_hw),
        BboxValidationOp(),
    ]
    train_dataset = PreprocessedDataset(dataset=raw_train_dataset, ops=preproc_ops)
    val_dataset = PreprocessedDataset(dataset=raw_val_dataset, ops=preproc_ops)
    result["preprocessed"] = (train_dataset, val_dataset)

    # Prepare augmentations
    train_augmentations = object_from_dict(
        d=config.train.augmentation,
        target_sz_hw=config.model.infer_sz_hw,
    )
    train_dataset = AugmentedDataset(dataset=train_dataset, aug=train_augmentations)
    result["augmented"] = (train_dataset, None)

    # Special names to keep train_dataset
    train_tensor_dataset = Image2TensorDataset(
        dataset=train_dataset, scale_div=config.train.data.scale_div
    )
    val_tensor_dataset = Image2TensorDataset(
        dataset=val_dataset, scale_div=config.train.data.scale_div
    )
    result["tensor"] = (train_tensor_dataset, val_tensor_dataset)

    return result


def train(config, dry_run=False):
    set_determenistic(42)

    # Additional variable from initial config
    config.model.n_outputs = len(config.model.strides)
    config.model.n_classes = len(config.model.labels)

    et_logger = ExperimentTrackingLogger(
        experiment_name=config.experiment_name
    )

    try:
        train_config = config.train
        model_config = config.model

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"Using device {device}")
        logger.info(f"Using model config {config.model}")

        datasets = load_datasets(config)

        train_tensor_dataset, val_tensor_dataset = datasets["tensor"]

        # Serialize preprocessing
        preprocessing_ops = list(datasets["preprocessed"][0].get_ops())
        preprocessing_ops.append(train_tensor_dataset.op)
        config.model.preprocessing = serialize_preprocessing(
            preprocessing_ops
        )
        
        # Serialize all preprocessings
        # This dict can ba hashed to keep modifications
        preprocessing_info = {
            "preprocessing": config.model.preprocessing,
            "train_augmentation": datasets["augmented"][0].get_augmentations().serialize(),
        }

        subbatch_sz = int(train_config.batch) // int(train_config.subdivisions)

        pin_memory = train_config.get("pin_memory", False)
        num_workers = train_config.num_workers

        if num_workers < 0:
            import multiprocessing

            num_workers = multiprocessing.cpu_count()

        logger.info(f"Workers used for training: {num_workers}")

        train_loader = DataLoader(
            train_tensor_dataset,
            batch_size=subbatch_sz,
            shuffle=True,
            num_workers=num_workers,
            pin_memory=pin_memory,
            drop_last=False,
        )
        val_loader = DataLoader(
            val_tensor_dataset,
            batch_size=subbatch_sz,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=pin_memory,
            drop_last=False,
        )

        # Create inference and evaluation object
        infer = InferDetection.from_config(
            model_config=model_config,
            device=device,
            nms_threshold=0.5,
            conf_threshold=0.001,
        )
        evaluator = BatchEvaluator(
            infer=infer,
            # We should put raw here to process source data
            datasets=[datasets["raw"][1]],
            batch_size=subbatch_sz,
            metrics_eval=MetricsEvaluator(labels=config.model.labels),
        )

        train_model = construct_model(model_config)
        initialize_weights(train_model)

        if "pretrained" in config.train:
            loader = FilepathLoader()
            pretrained_path = loader.load_path(config.train.pretrained)
            loaded_data = torch.load(pretrained_path)
            train_model.load_state_dict(loaded_data["model_state"])
            logger.info(f"Loaded weights from {pretrained_path}")

        train_model.to(device)

        optimizer = object_from_dict(
            d=train_config.optimizer,
            params=train_model.parameters(),
            lr=float(train_config.lr),
        )

        scheduler = object_from_dict(
            d=train_config.scheduler,
            optimizer=optimizer,
        )

        ARTIFACTS_CACHE_DIR = train_config.artifacts_dir
        os.makedirs(ARTIFACTS_CACHE_DIR, exist_ok=True)

        CHECKPOINT_NAME_MAIN = f"{config.experiment_name}_{train_model.__name__}"

        logger.debug(f"Model name: {train_model.__name__}")

        et_logger.set_tags({"model": train_model.__name__})
        if not dry_run:
            et_logger.initialize(config.metrics_logger)

        logger.debug(
            f"Evaluation Tracking logger experiment version: {et_logger.version}"
        )

        # Log config file
        et_logger.log_artifact(
            local_path=write_temp_yml(
                config.to_dict(), fname="config.yml", dir=ARTIFACTS_CACHE_DIR
            )
        )
        et_logger.log_artifact(
            local_path=write_temp_yml(
                preprocessing_info,
                fname="preprocessing.yml",
                dir=ARTIFACTS_CACHE_DIR,
            )
        )

        params = {
            "optimizer": train_config.optimizer.type,
            "scheduler": train_config.scheduler.type,
            "initial_lr": train_config.lr,
            "epochs": train_config.epochs,
            "input_size": str(
                (model_config.infer_sz_hw[1], model_config.infer_sz_hw[0])
            ),
            # And other required params...
        }
        et_logger.log_hyperparams(params=params)

        global_step = 0
        epochs = train_config.epochs

        # Create metrics tracker for checkpoints collection
        tracking_metrics = config.train.checkpoints_metrics
        metric_tracker = MetricTracker(metric_names=[m.name for m in tracking_metrics])

        trainer = SubbatchTrainer(
            epochs=config.train.epochs,
            batch_subdiv=config.train.subdivisions
        )

        for epoch in range(epochs):
            curr_lr = get_lr(optimizer)
            logger.debug(f"Current lr: {curr_lr}")

            train_losses = trainer.train_epoch(
                epoch=epoch, 
                model=train_model, 
                loader=train_loader, 
                optimizer=optimizer,
                phase='train'
            )

            val_losses = trainer.train_epoch(
                epoch=epoch, 
                model=train_model, 
                loader=val_loader, 
                optimizer=optimizer, 
                phase='valid'
            )

            # Average losses
            train_losses = {k: np.mean(v) for k, v in train_losses.items()}
            val_losses = {k: np.mean(v) for k, v in val_losses.items()}

            logger.debug(f"Train losses: {train_losses}")
            logger.debug(f"Valid losses: {val_losses}")

            epoch_loss = train_losses["loss"]
            val_epoch_loss = val_losses["loss"]
            logger.info(f"Train epoch loss: {epoch_loss}")
            logger.info(f"Valid epoch loss: {val_epoch_loss}")

            # Update scheduler
            scheduler.step()
            # scheduler.step(val_epoch_loss)

            full_metrics = {
                "lr": curr_lr,
                "train": train_losses,
                "val": val_losses,
            }

            # --- EVALUATION PART ---
            # Evaluate on later epochs as at start network returns too many items
            skip_eval_epochs = int(train_config.get("skip_eval_epochs", 0))
            if epoch >= skip_eval_epochs:
                logger.info("Start evauation")
                infer.update_model_state(train_model.state_dict())
                full_metrics["eval"] = evaluator()

            # Flatten to make writtable to loggers
            flat_full_metrics = flatten_dict(full_metrics)
            logger.debug(flat_full_metrics)

            et_logger.log_metrics(metrics=flat_full_metrics, step=epoch)

            # --- SAVE CHECKPOINTS ROUTINE ---
            save_data = {
                "model_state": train_model.state_dict(),
                "model_config": dict(model_config),
            }
            logger.debug(f'Save model config: {dict(model_config)}')

            chk_name = f"{CHECKPOINT_NAME_MAIN}_last.pth"
            save_path = os.path.join(ARTIFACTS_CACHE_DIR, chk_name)
            torch.save(
                save_data,
                save_path,
                # For backward compatibility
                _use_new_zipfile_serialization=False,
            )
            logger.info(f"Checkpoint for last epoch {epoch + 1} saved!")

            et_logger.log_artifact(local_path=save_path)

            updates, best_stats = metric_tracker.check(epoch, flat_full_metrics)
            # If one of tracking metrics updated
            if len(updates) > 0:
                best_stats_filepath = os.path.join(
                    ARTIFACTS_CACHE_DIR, "best_stats.json"
                )
                with open(best_stats_filepath, "w") as f:
                    json.dump(best_stats, f)

                et_logger.log_artifact(local_path=best_stats_filepath)

                for update in updates:
                    m_name = update["name"].split("/", 1)[1]
                    chk_name = f"{CHECKPOINT_NAME_MAIN}_best_{m_name}.pth"

                    # Checkpoint save
                    save_path = os.path.join(ARTIFACTS_CACHE_DIR, chk_name)

                    torch.save(
                        save_data,
                        save_path,
                        # For backward compatibility
                        _use_new_zipfile_serialization=False,
                    )
                    logger.info(f"Checkpoint for best {m_name} on {epoch + 1} saved!")

                    et_logger.log_artifact(local_path=save_path)

        et_logger.finalize(status="FINISHED")
    except Exception as e:
        logger.error(f"Train failed: {e}")
        et_logger.finalize(status="FAILED")
        raise

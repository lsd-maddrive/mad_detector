from lxml import etree as et


class CvatAnnotationExporter(object):
    def __init__(self, version='1.1'):
        self.version = version
        self.root = et.Element('annotations')

        version_el = et.SubElement(self.root, 'version')
        version_el.text = version

        print(et.tostring(self.root))

        self.image_el = None
        self.global_id = 0

    def set_image(self, info):
        self.image_el = et.SubElement(
            self.root, 'image',
            id=str(self.global_id),
            name=info['name'],
            width=str(info['width']),
            height=str(info['height']),
        )

        self.global_id += 1
        return self.global_id-1

    def add_bbox(self, bbox, label, is_occluded=False):
        bbox_el = et.SubElement(
            self.image_el, 'box',
            label=label,
            occluded='0' if not is_occluded else '1',
            xtl=str(bbox[0]),
            ytl=str(bbox[1]),
            xbr=str(bbox[0]+bbox[2]),
            ybr=str(bbox[1]+bbox[3])
        )

    def export_to_file(self, fpath):
        et.ElementTree(self.root).write(
            fpath, 
            pretty_print=True,
            xml_declaration=True, 
            encoding='UTF-8'
        )

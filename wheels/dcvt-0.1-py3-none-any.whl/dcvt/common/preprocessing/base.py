import cv2
import numpy as np
import torch
from ..utils import image as imut
import logging

logger = logging.getLogger(__name__)


def serialize_preprocessing(ops):
    descriptions = []
    for op in ops:
        data = op.serialize()
        data['type'] = op.TYPE
        logger.debug(data)
        descriptions.append(data)
    return descriptions


class BasePreprocessingOp(object):
    @staticmethod
    def deserialize(op_desc, supported_ops):
        TYPES = {op.TYPE: op for op in supported_ops}
        type_ = op_desc["type"]

        for op in supported_ops:
            if type_ != op.TYPE:
                continue

            return TYPES[type_].from_description(**op_desc)

        raise NotImplementedError(f'Method with description {op_desc} not found')

    def transform(self, img: np.ndarray, ann: dict = None, data: dict = {}):
        raise NotImplementedError('Must be implemented')

    def inverse_transform(self, preds, data: dict):
        raise NotImplementedError('Must be implemented')

    def serialize(self):
        raise NotImplementedError('Must be implemented')

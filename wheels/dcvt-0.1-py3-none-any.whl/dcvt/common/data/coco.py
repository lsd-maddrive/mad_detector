import os
import numpy as np
import cv2
from pycocotools.coco import COCO
from pycocotools import mask as maskUtils

from . base import BaseImageDataset

import logging
logger = logging.getLogger(__name__)


class BaseCocoDataset(BaseImageDataset):
    def __init__(
        self,
        root_dirpath,
        img_sdirpath,
        ann_sfpath,
        labels,
        labels_map={},
        n_images=-1,
        background_name='__background__',
        **other
    ):
        super().__init__(**other)

        self.labels = labels

        self.root_dpath = root_dirpath
        if img_sdirpath is None:
            self.imgs_dpath = self.root_dpath
        else:
            self.imgs_dpath = os.path.join(self.root_dpath, img_sdirpath)

        if ann_sfpath is None:
            raise ValueError('COCO must be provided with annotation filepath')

        self.ann_fpath = os.path.join(self.root_dpath, ann_sfpath)

        self.coco = COCO(self.ann_fpath)
        self.coco_id_2_label_id = {}

        def map_label_id(dataset_label, train_label_id):
            try:
                coco_id = self.coco.getCatIds(catNms=[dataset_label])[0]
                self.coco_id_2_label_id[coco_id] = train_label_id
            except Exception as e:
                logger.error('Category not found: {} in {}'.format(dataset_label, ann_sfpath))
                return

        for label_id, label in enumerate(self.labels):
            if label == background_name:
                continue
            
            if label not in labels_map:
                map_label_id(label, label_id)
            else:
                for dataset_label in labels_map[label]:
                    map_label_id(dataset_label, label_id)

        self.img_ids = set()
        self.cat_ids = self.coco_id_2_label_id.keys()

        # Find images where categories exist
        for cat_id in self.cat_ids:
            img_ids = self.coco.getImgIds(catIds=cat_id)
            self.img_ids |= set(img_ids)

        self.img_ids = list(self.img_ids)

        logger.info('Processing images info')

        self.image_infos = []
        for i in self.img_ids:
            info = {
                'id': int(i)
            }
            image_info = self.coco.loadImgs(i)[0]

            filename = image_info['file_name']
            if os.sep in filename:
                filename = os.path.basename(filename)

            info['filepath'] = os.path.join(self.imgs_dpath, filename)
            info['width'] = int(image_info['width'])
            info['height'] = int(image_info['height'])
            info['annotations'] = self.coco.loadAnns(
                self.coco.getAnnIds(imgIds=i, catIds=self.cat_ids)
            )

            self.image_infos.append(info)

            # Apply limitation
            if n_images > 0 and len(self.image_infos) >= n_images:
                break
        
        logger.debug(len(self))
        if other.get('show_stats', False):
            logger.info(f'Dataset {__class__} readed {len(self)} annotations')

    def __len__(self):
        return len(self.image_infos)

    def get_bboxes(self, index):
        info = self.image_infos[index]
        anns = info['annotations']
        
        bboxes = np.zeros((len(anns), 5), dtype=np.float32)
        for i, ann in enumerate(anns):
            label_id = self.coco_id_2_label_id[ann['category_id']]
            bboxes[i,:4] = ann['bbox']
            bboxes[i,4] = label_id

        return bboxes

    def get_masks(self, index):
        info = self.image_infos[index]
        anns = info['annotations']
        height, width = info['height'], info['width']

        masks = np.zeros((height, width, len(self.labels)), dtype=np.uint32)

        for ann in anns:
            label_id = self.coco_id_2_label_id[ann['category_id']]
            instance_mask = self._ann2mask(ann, info['width'], info['height'])
            ys, xs = np.where(instance_mask > 0)
            masks[ys, xs, label_id] = 255 

        return masks
    
    def get_cat_mask(self, index):
        info = self.image_infos[index]
        anns = info['annotations']
        height, width = info['height'], info['width']

        mask = np.zeros((height, width), dtype=np.uint32)

        for ann in anns:
            label_id = self.coco_id_2_label_id[ann['category_id']]
            instance_mask = self._ann2mask(ann, info['width'], info['height'])
            ys, xs = np.where(instance_mask > 0)
            mask[ys, xs] = label_id 

        return mask

    def _ann2mask(self, ann, width, height):
        segm = ann['segmentation']
        if isinstance(segm, list):
            # polygon -- a single object might consist of multiple parts
            # we merge all parts into one mask rle code
            rles = maskUtils.frPyObjects(segm, height, width)
            rle = maskUtils.merge(rles)
        elif isinstance(segm['counts'], list):
            # uncompressed RLE
            rle = maskUtils.frPyObjects(segm, height, width)
        else:
            # rle
            rle = ann['segmentation']

        m = maskUtils.decode(rle)
        return m

    def get_image(self, index):
        img_fpath = self.image_infos[index]['filepath']
        img = cv2.imread(img_fpath)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        return img

    def image_reference(self, index):
        """Return a link to the image in the COCO Website."""
        info = self.image_infos[index]
        return "http://cocodataset.org/#explore?id={}".format(info["id"])
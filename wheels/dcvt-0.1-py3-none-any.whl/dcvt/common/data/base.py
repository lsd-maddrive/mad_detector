import bisect
from ..utils.common import object_from_dict


class BaseImageDataset(object):
    def __init__(self, **config):
        pass

    def __getitem__(self, index):
        """Return pair (image, annotation)

        Args:
            index (int): Index to retrieve pair

        Return:
            img (np.ndarray[h, w, c]): Image from dataset
            ann (Dict[str, Any]): Annotation for image
                bboxes (np.ndarray(n, 4)): Bounding boxes on image
                labels (np.ndarray(n)): Labels for bboxes
                cat_mask (np.ndarray(h, w)): Categorical mask
        """
        raise NotImplementedError('This method must be implemented!')


class ConcatDatasets(BaseImageDataset):
    def __init__(self, datasets: list):
        self.datasets = datasets

        self.common_len = 0
        self.cumulative_sizes = []
        for ds in datasets:
            self.common_len += len(ds)
            self.cumulative_sizes.append(self.common_len)

    def __getitem__(self, index):
        dataset_idx = bisect.bisect_right(self.cumulative_sizes, index)
        dataset = self.datasets[dataset_idx]

        if dataset_idx > 0:
            index -= self.cumulative_sizes[dataset_idx-1]

        img, ann = dataset[index]
        return img, ann

    def __len__(self):
        return self.common_len


class PreprocessedDataset(BaseImageDataset):
    def __init__(self, dataset: list, ops: list):
        self.dataset = dataset
        self.ops = ops

    def __getitem__(self, index):
        img, ann = self.dataset[index]

        data = {}
        for op in self.ops:
            img, ann = op.transform(img, ann, data)

        return img, ann

    def __len__(self):
        return len(self.dataset)

    def get_ops(self):
        return self.ops


class AugmentedDataset(BaseImageDataset):
    def __init__(self, dataset: list, aug: object):
        self.dataset = dataset
        self.aug = aug

    def __getitem__(self, index):
        img, ann = self.dataset[index]
        img, ann = self.aug.transform(img, ann)

        return img, ann

    def __len__(self):
        return len(self.dataset)

    def get_augmentations(self):
        return self.aug


def create_dataset(
    dataset_config: dict,
    part: str,
    labels: list,
    type_mapping: dict
):
    datasets_list = []
    root_config = dataset_config.get('config', {})

    for cfg in dataset_config.get(part, []):
        _type = cfg.type
        if _type in type_mapping:
            # Remap dataset path
            _type = cfg.type = type_mapping[_type]
            # raise Exception('Unknown dataset type: {}'.format(_type))

        # Get common config and update with special config
        _config = root_config.copy()
        _config.update(cfg)
        _config['labels'] = labels
        
        try:
            dataset = object_from_dict(_config)
        except:
            raise Exception(f'Failed to create dataset with type: {_type}')

        # dataset = _datasets[_type](**_config)
        datasets_list.append(dataset)

    return datasets_list

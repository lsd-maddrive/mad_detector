import os
from tqdm import tqdm
import torch

from ..utils.torch import get_model_device

import logging
logger = logging.getLogger(__name__)


class SubbatchTrainer(object):
    def __init__(self, epochs, batch_subdiv):
        self.epochs = int(epochs)
        self.batch_subdiv = int(batch_subdiv)
        self.loss_ratio = self.batch_subdiv
        self.train_step = 0

    def train_epoch(self, epoch, model, loader, optimizer, phase='train'):
        assert phase in ['train', 'valid']

        losses = {"loss": []}

        if phase in ['train']:
            model.train()
        else:
            model.eval()

        device = get_model_device(model)

        with torch.set_grad_enabled(phase=='train'):
            with tqdm(
                total=len(loader.dataset),
                desc=f"Epoch [{phase}] {epoch + 1}/{self.epochs}",
                unit="img",
                ncols=80
            ) as pbar:
                for batch in loader:
                    self.train_step += 1
                    images = batch[0].to(device=device)
                    targets = batch[1].to(device=device)

                    c_batch_sz = images.shape[0]

                    preds = model(images)
                    main_loss, loss_parts = model.loss(preds, targets)
                    if torch.isnan(main_loss):
                        raise ValueError("Train Loss turned nan")

                    main_loss = main_loss / self.loss_ratio

                    losses["loss"].append(main_loss.item())
                    pbar.update(c_batch_sz)

                    # Criterion provides named parts
                    for loss_name, loss_val in loss_parts.items():
                        if torch.isnan(loss_val):
                            continue

                        _name = f"loss_{loss_name}"
                        if _name not in losses:
                            losses[_name] = []

                        losses[_name].append(loss_val.item() / self.loss_ratio)

                    if phase in ['train']:
                        main_loss.backward()
                        
                        if self.train_step % self.batch_subdiv  == 0:
                            optimizer.step()
                            optimizer.zero_grad()

        return losses

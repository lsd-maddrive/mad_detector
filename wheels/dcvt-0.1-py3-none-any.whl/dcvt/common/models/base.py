import torch
from torch import nn


class ImageProcessingModel(nn.Module):
    def __init__(self, **config):
        super().__init__()
        self.config = config

    def loss(self, y_pred, y_true):
        raise NotImplementedError('Must be implemented')

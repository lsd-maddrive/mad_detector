import logging

import argparse
from . common import unflatten_dict, merge_update_dicts

logger = logging.getLogger(__name__)


def get_args():
    parser = argparse.ArgumentParser(description='Train the Model',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-c', '--config', 
                        nargs='+',
                        type=str, 
                        required=True)
    parser.add_argument('-d', '--dry-run', action='store_true')
    parser.add_argument('-p', "--params",
                        metavar="KEY=VALUE",
                        nargs='+',
                        help="Set a number of key-value pairs "
                             "(do not put spaces before or after the = sign). "
                             "If a value contains spaces, you should define "
                             "it with double quotes: "
                             'train.exp_name="this is a sentence". Note that '
                             "values are always treated as strings.")
    args = vars(parser.parse_args())
    logger.debug(f'Input args: {args}')
    return args


def parse_args_params(arg_params):
    if arg_params is None:
        return {}

    params_dict = dict()
    for param in arg_params:
        key, value = param.split('=', 1)
        params_dict[key] = value

    params_dict = unflatten_dict(params_dict)
    logger.debug(f'Arg params: {params_dict}')
    return params_dict

import os

UTILS_ROOT=os.path.realpath(os.path.dirname(__file__))
PACKAGE_ROOT=os.path.join(UTILS_ROOT, '..', '..', '..')

import os
import time
import re
import logging
from typing import Any, Dict, Optional, Union

import mlflow
from mlflow.tracking import MlflowClient

from .common import object_from_dict

logger = logging.getLogger(__name__)

# This is just cover for real logger to check None
class ExperimentTrackingLogger(object):
    def __init__(self, experiment_name):
        self.experiment_name = experiment_name
        self.tags = {}
        self.logger = None

    @property
    def version(self) -> str:
        if self.logger is None:
            return 'Not initialized'
        
        return self.logger.version

    def set_tags(self, tags):
        self.tags = tags

    def initialize(self, config):
        self.logger = object_from_dict(
            config,
            experiment_name=self.experiment_name,
            tags=self.tags
        )

    def log_artifact(self, **kwargs) -> None:
        if self.logger is None:
            return

        if not hasattr(self.logger, "log_artifact"):
            return

        self.logger.log_artifact(**kwargs)

    def log_metrics(self, **kwargs) -> None:
        if self.logger is None:
            return

        if not hasattr(self.logger, "log_metrics"):
            return

        self.logger.log_metrics(**kwargs)

    def log_hyperparams(self, **kwargs) -> None:
        if self.logger is None:
            return

        if not hasattr(self.logger, "log_hyperparams"):
            return

        self.logger.log_hyperparams(**kwargs)

    def finalize(self, **kwargs) -> None:
        if self.logger is None:
            return

        if not hasattr(self.logger, "finalize"):
            return

        self.logger.finalize(**kwargs)


class MlFLowMinioLogger(object):
    def __init__(
        self,
        experiment_name,
        tracking_uri=None,
        tags=None,
        mlflow_uri=None,
        secret_access_key=None,
        access_key=None,
        include_git_hash=True,
    ):

        if access_key is not None:
            os.environ["AWS_SECRET_ACCESS_KEY"] = secret_access_key

        if secret_access_key is not None:
            os.environ["AWS_ACCESS_KEY_ID"] = access_key

        if mlflow_uri is not None:
            os.environ["MLFLOW_S3_ENDPOINT_URL"] = mlflow_uri

        if tracking_uri is not None:
            os.environ["MLFLOW_TRACKING_URL"] = tracking_uri

        self._experiment_name = experiment_name
        self._experiment_id = None
        self._tracking_uri = os.getenv("MLFLOW_TRACKING_URL")
        self._run_id = None
        self.tags = tags
        if self.tags is None:
            self.tags = {}

        if include_git_hash:
            import git

            repo = git.Repo(search_parent_directories=True)
            tags.update({"commit": repo.head.object.hexsha})

        self._mlflow_client = MlflowClient(self._tracking_uri)

    @property
    def experiment(self) -> MlflowClient:
        if self._experiment_id is None:
            expt = self._mlflow_client.get_experiment_by_name(self._experiment_name)
            if expt is not None:
                self._experiment_id = expt.experiment_id
            else:
                logger.warning(
                    f"Experiment with name {self._experiment_name} not found. Creating it."
                )
                self._experiment_id = self._mlflow_client.create_experiment(
                    name=self._experiment_name
                )

        if self._run_id is None:
            run = self._mlflow_client.create_run(
                experiment_id=self._experiment_id, tags=self.tags
            )
            self._run_id = run.info.run_id
        return self._mlflow_client

    @property
    def run_id(self):
        # create the experiment if it does not exist to get the run id
        _ = self.experiment
        return self._run_id

    @property
    def version(self) -> str:
        return self.run_id

    def log_artifact(self, **kwargs) -> None:
        kwargs.update({"run_id": self.run_id})
        self.experiment.log_artifact(**kwargs)

    def log_hyperparams(self, params: Dict[str, Any]) -> None:
        for k, v in params.items():
            self.experiment.log_param(self.run_id, k, v)

    def log_metrics(
        self, metrics: Dict[str, float], step: Optional[int] = None
    ) -> None:
        timestamp_ms = int(time.time() * 1000)
        for k, v in metrics.items():
            if isinstance(v, str):
                logger.warning(f"Discarding metric with string value {k}={v}.")
                continue

            new_k = re.sub("[^a-zA-Z0-9_/. -]+", "", k)
            if k != new_k:
                logger.warning(
                    "MLFlow only allows '_', '/', '.' and ' ' special characters in metric name."
                    f" Replacing {k} with {new_k}"
                )
                k = new_k

            self.experiment.log_metric(self.run_id, k, v, timestamp_ms, step)

    def finalize(self, status: str = "FINISHED") -> None:
        status = "FINISHED" if status.lower() == "success" else status
        if self.experiment.get_run(self.run_id):
            self.experiment.set_terminated(self.run_id, status)

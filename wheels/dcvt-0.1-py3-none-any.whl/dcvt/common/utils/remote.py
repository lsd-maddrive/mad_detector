import shutil
import os
import urllib
import boto3
from dotenv import load_dotenv
import logging

logger = logging.getLogger(__name__)

# Special setup to disable
logging.getLogger('s3transfer').setLevel(logging.ERROR)
logging.getLogger('urllib3').setLevel(logging.ERROR)
logging.getLogger('botocore').setLevel(logging.ERROR)


def init(dotenv_path='.env'):
    load_dotenv(dotenv_path=dotenv_path, verbose=True)


def download_s3_model(path, dirpath):
    logger.info('Downloading {}'.format(path))
    result = urllib.parse.urlparse(path, allow_fragments=False)

    rem_fname = os.path.basename(result.path)
    local_fpath = os.path.join(dirpath, rem_fname)

    client = boto3.client(
        's3', endpoint_url=os.environ['MLFLOW_S3_ENDPOINT_URL'])
    client.download_file(result.netloc, result.path, local_fpath)

    return local_fpath

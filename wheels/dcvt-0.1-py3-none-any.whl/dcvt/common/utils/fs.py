import os

def get_images_from_directory(
    dirpath, 
    img_extentions=['png', 'jpg', 'jpeg', 'bmp', 'gif'], 
    is_recursive=False
):
    if is_recursive:
        fpaths = [
            os.path.join(dp, fname)
            for dp, dn, filenames in os.walk(dirpath)
            for fname in filenames
            if fname.split('.')[-1].lower() in img_extentions
        ]
    else:
        fpaths = [
            os.path.join(dirpath, fname)
            for fname in os.listdir(dirpath)
            if fname.split('.')[-1].lower() in img_extentions
        ]

    return fpaths
    


class FilepathLoader(object):
    def __init__(self, cache_directory='cache'):
        self.cache_directory = cache_directory
    
    def load_path(self, path):
        from .remote import download_s3_model
        
        if path.startswith('s3://'):
            path = download_s3_model(path, dirpath=self.cache_directory)

        return path


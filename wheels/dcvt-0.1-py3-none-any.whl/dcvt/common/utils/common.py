import numpy as np
import torch
import math
import random
import os
import pydoc

from collections.abc import MutableMapping


def object_from_dict(d, parent=None, **default_kwargs):
    assert isinstance(d, dict) and "type" in d
    kwargs = d.copy()
    object_type = kwargs.pop("type")

    for name, value in default_kwargs.items():
        kwargs.setdefault(name, value)

    # support nested constructions
    for key, value in kwargs.items():
        if isinstance(value, dict) and "type" in value:
            value = object_from_dict(value)
            kwargs[key] = value

    if parent is not None:
        return getattr(parent, object_type)(**kwargs)
    else:
        return pydoc.locate(object_type)(**kwargs)


def flatten_dict(data):
    reformated_data = {}

    for root_key, value in data.items():
        if isinstance(value, dict):
            sub_dict = flatten_dict(value)
            for sub_key, sub_value in sub_dict.items():
                new_key = f'{root_key}/{sub_key}'
                reformated_data[new_key] = sub_value
        elif isinstance(value, (np.ndarray, list)):
            for i, val in enumerate(value):
                new_key = f'{root_key}_{i}'
                reformated_data[new_key] = val
        else:
            reformated_data[root_key] = value

    return reformated_data


def unflatten_dict(dictionary, sep='.'):
    resultDict = dict()
    for key, value in dictionary.items():
        parts = key.split(sep)
        d = resultDict
        for part in parts[:-1]:
            if part not in d:
                d[part] = dict()
            d = d[part]
        d[parts[-1]] = value
    return resultDict


def merge_update_dicts(src_dict, new_dict):
    for k, v in new_dict.items():
        if k not in src_dict:
            src_dict[k] = v
        else:
            if isinstance(v, MutableMapping) and isinstance(src_dict[k], MutableMapping):
                src_dict[k] = merge_update_dicts(src_dict[k], v)
            else:
                src_dict[k] = v

    return src_dict


def set_determenistic(seed=42, precision=10):
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.cuda.manual_seed_all(seed)
    torch.manual_seed(seed)
    torch.set_printoptions(precision=precision)


class MetricTracker(object):
    def __init__(self, metric_names):
        self.metric_names = metric_names
        self.metrics_stat = {name: {
            'best': 0,
            'epoch': -1
        } for name in self.metric_names}

    def check(self, epoch, metrics):
        updated_list = []

        for m_name, data in self.metrics_stat.items():
            if m_name not in metrics:
                continue

            value = metrics[m_name]
            if value >= data['best']:
                data['best'] = value
                data['epoch'] = epoch

                updated_list.append({
                    'name': m_name
                })

        return updated_list, self.metrics_stat

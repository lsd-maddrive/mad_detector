import torch
import torch.nn as nn
from torch.nn import BatchNorm2d

        
def initialize_weights(model):
    for m in model.modules():
        t = type(m)
        if t is nn.Conv2d:
            pass  # nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
        elif t is nn.BatchNorm2d:
            m.eps = 1e-3
            m.momentum = 0.03
        elif t in [nn.LeakyReLU, nn.ReLU, nn.ReLU6]:
            m.inplace = True
 
    
def get_lr(optimizer):
    return optimizer.param_groups[0]['lr']
    

def set_half_precision(model):
    model.half()
    for layer in model.modules():
        if isinstance(layer, BatchNorm2d):
            layer.float()


def get_model_device(model):
    return next(model.parameters()).device

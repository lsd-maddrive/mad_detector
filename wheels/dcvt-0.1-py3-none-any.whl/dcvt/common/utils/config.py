import os
import yaml
from addict import Dict
from . common import unflatten_dict, merge_update_dicts


def read_config(config_path):
    with open(config_path) as file:
        config = yaml.safe_load(file)

    # Precalculate some parameters
    config = Dict(config)

    return config


def write_temp_yml(data, fname='config.yml', dir='tmp'):
    os.makedirs(dir, exist_ok=True)
    fpath = os.path.join(dir, fname)

    with open(fpath, 'w') as f:
        yaml.safe_dump(data, f, default_flow_style=None)

    return fpath


def read_multiple_configs(configs):
    from addict import Dict

    result_config = {}

    for path in configs:
        config = read_config(path)
        result_config = merge_update_dicts(result_config, config)

    return Dict(result_config)

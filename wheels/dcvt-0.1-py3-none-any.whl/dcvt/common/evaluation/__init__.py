import numpy as np
import logging

from tqdm import tqdm


class BatchEvaluator():
    def __init__(self, infer, datasets, metrics_eval, batch_size=1):
        self.infer = infer
        self.datasets = datasets
        self.batch_size = batch_size
        self.metrics_eval = metrics_eval

        self.logger = logging.getLogger(__name__)

    def __call__(self):
        self.metrics_eval.clear()

        image_id = 0
        _images_list = []
        _trues_list = []

        self.logger.debug('Start predictions')

        def perform_prediction():
            predictions = self.infer.infer_batch(_images_list)
            local_image_ids = image_id

            for i_pred, pred in enumerate(predictions):
                self.metrics_eval.append_sample(
                    pred, _trues_list[i_pred]
                )

                local_image_ids += 1

            return local_image_ids

        global_len = sum([len(ds) for ds in self.datasets])
        self.logger.debug(f'Processing {global_len} samples for evaluation')
        
        with tqdm(total=global_len, desc=f'Evaluation', unit='img', ncols=80) as pbar:
            for dataset in self.datasets:
                for i in range(len(dataset)):
                    img, ann = dataset[i]

                    _images_list.append(img)
                    _trues_list.append(ann)

                    if len(_images_list) >= self.batch_size:
                        image_id = perform_prediction()
                        pbar.update(len(_images_list))
                        _images_list.clear()
                        _trues_list.clear()
                    
            # Last predictions
            if len(_images_list) > 0:
                image_id = perform_prediction()
                pbar.update(len(_images_list))

        self.logger.debug('Predictions done, start calculating metrics')
        return self.metrics_eval.get_metrics()

